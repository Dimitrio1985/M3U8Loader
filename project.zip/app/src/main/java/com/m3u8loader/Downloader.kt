package com.m3u8loader

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CancellationException
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

object Downloader {

    private class Sink(val stream: OutputStream, val finish: () -> Unit, val abort: () -> Unit)

    fun run(ctx: Context, item: Item, onProgress: () -> Unit) {
        if (item.cancelled) {
            item.status = Status.CANCELLED
            Store.changed()
            return
        }
        item.status = Status.DOWNLOADING
        item.progress = 0
        Store.changed()

        var sink: Sink? = null
        try {
            var url = item.url
            var text = Playlist.fetchText(url)
            if (Playlist.isMaster(text)) {
                val best = Playlist.parseMaster(text, url).maxByOrNull { it.bandwidth }
                    ?: throw IllegalStateException("пустой мастер-плейлист")
                url = best.url
                text = Playlist.fetchText(url)
            }
            val media = Playlist.parseMedia(text, url)
            val mp4 = media.mapUrl != null
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val fileName = item.name + "_" + stamp + (if (mp4) ".mp4" else ".ts")
            val s = openSink(ctx, fileName, if (mp4) "video/mp4" else "video/MP2T")
            sink = s

            media.mapUrl?.let { s.stream.write(getBytes(it)) }

            val keys = HashMap<String, ByteArray>()
            val total = media.segments.size
            for ((i, seg) in media.segments.withIndex()) {
                if (item.cancelled) throw CancellationException()
                var data = getBytes(seg.url)
                val keyUrl = seg.keyUrl
                if (keyUrl != null) {
                    val key = keys.getOrPut(keyUrl) { getBytes(keyUrl) }
                    data = decrypt(data, key, seg.iv ?: seqIv(seg.seq))
                }
                s.stream.write(data)
                item.progress = ((i + 1) * 100L / total).toInt()
                onProgress()
                Store.changed()
            }
            s.stream.flush()
            s.stream.close()
            s.finish()
            sink = null
            item.progress = 100
            item.message = "Загрузки/M3U8Loader/$fileName"
            item.status = Status.DONE
        } catch (e: CancellationException) {
            sink?.abort?.invoke()
            item.status = Status.CANCELLED
        } catch (e: Exception) {
            sink?.abort?.invoke()
            item.message = e.message ?: e.javaClass.simpleName
            item.status = Status.ERROR
        }
        Store.changed()
    }

    private fun getBytes(url: String): ByteArray {
        var last: Exception? = null
        for (attempt in 1..3) {
            try {
                val c = Playlist.open(url)
                try {
                    return c.inputStream.use { it.readBytes() }
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                last = e
                try { Thread.sleep(1000L * attempt) } catch (ie: InterruptedException) { break }
            }
        }
        throw last ?: IOException("ошибка загрузки")
    }

    private fun decrypt(data: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return c.doFinal(data)
    }

    private fun seqIv(seq: Long): ByteArray {
        val b = ByteArray(16)
        for (k in 0 until 8) b[15 - k] = (seq ushr (8 * k)).toByte()
        return b
    }

    private fun openSink(ctx: Context, name: String, mime: String): Sink {
        if (Build.VERSION.SDK_INT >= 29) {
            val r = ctx.contentResolver
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/M3U8Loader")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IOException("не удалось создать файл")
            val out = r.openOutputStream(uri) ?: throw IOException("не удалось открыть файл")
            return Sink(
                out,
                {
                    val u = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                    r.update(uri, u, null, null)
                },
                {
                    try { out.close() } catch (e: Exception) { }
                    r.delete(uri, null, null)
                }
            )
        }
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "M3U8Loader"
        )
        dir.mkdirs()
        val f = File(dir, name)
        val out = FileOutputStream(f)
        return Sink(
            out,
            { MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null) },
            {
                try { out.close() } catch (e: Exception) { }
                f.delete()
            }
        )
    }
}
