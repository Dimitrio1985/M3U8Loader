package com.m3u8loader

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var urlInput: EditText
    private val itemAdapter = ItemAdapter()
    private val bg = Executors.newSingleThreadExecutor()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "M3U8 Loader"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        })

        urlInput = EditText(this).apply {
            hint = "Ссылка на .m3u8"
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_VARIATION_URI or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE
            maxLines = 3
        }
        root.addView(urlInput, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pasteBtn = Button(this).apply {
            text = "Вставить"
            setOnClickListener { pasteFromClipboard() }
        }
        val addBtn = Button(this).apply {
            text = "В очередь"
            setOnClickListener { onAdd() }
        }
        row.addView(pasteBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(addBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        root.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        val list = ListView(this).apply {
            adapter = itemAdapter
            setOnItemClickListener { _, _, pos, _ -> showActions(itemAdapter.getItem(pos)) }
        }
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setContentView(root)

        val perms = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT < 29) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        Store.listener = { itemAdapter.refresh() }
        itemAdapter.refresh()
    }

    override fun onStop() {
        Store.listener = null
        super.onStop()
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val text = when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i.dataString
            else -> null
        } ?: return
        val m = Regex("https?://\\S+").find(text) ?: return
        urlInput.setText(m.value)
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val t = clip.getItemAt(0).coerceToText(this)?.toString()
            if (!t.isNullOrBlank()) urlInput.setText(t.trim())
        }
    }

    private fun onAdd() {
        val url = urlInput.text.toString().trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            toast("Введите ссылку, начинающуюся с http:// или https://")
            return
        }
        toast("Проверяю плейлист…")
        bg.execute {
            try {
                val text = Playlist.fetchText(url)
                if (Playlist.isMaster(text)) {
                    val variants = Playlist.parseMaster(text, url)
                    runOnUiThread { chooseQuality(url, variants) }
                } else {
                    runOnUiThread { enqueue(url, Playlist.baseName(url)) }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Не удалось открыть: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    private fun chooseQuality(sourceUrl: String, variants: List<Variant>) {
        val sorted = variants.sortedByDescending { it.bandwidth }
        val labels = sorted.map { it.label() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Качество")
            .setItems(labels) { _, i ->
                enqueue(sorted[i].url, Playlist.baseName(sourceUrl) + sorted[i].suffix())
            }
            .show()
    }

    private fun enqueue(mediaUrl: String, name: String) {
        Store.add(mediaUrl, name)
        Store.changed()
        urlInput.setText("")
        val svc = Intent(this, DownloadService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        toast("Добавлено в очередь")
    }

    private fun showActions(item: Item) {
        val opts = when (item.status) {
            Status.QUEUED, Status.DOWNLOADING -> arrayOf("Отменить")
            Status.DONE -> arrayOf("Удалить из списка")
            else -> arrayOf("Повторить", "Удалить из списка")
        }
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(opts) { _, i ->
                when (opts[i]) {
                    "Отменить" -> {
                        Store.cancel(item)
                        Store.changed()
                    }
                    "Повторить" -> {
                        Store.remove(item)
                        enqueue(item.url, item.name)
                    }
                    else -> {
                        Store.remove(item)
                        Store.changed()
                    }
                }
            }
            .show()
    }

    private fun statusText(item: Item): String = when (item.status) {
        Status.QUEUED -> "В очереди"
        Status.DOWNLOADING -> "Загрузка: ${item.progress}%"
        Status.DONE -> "Готово · ${item.message}"
        Status.ERROR -> "Ошибка: ${item.message}"
        Status.CANCELLED -> "Отменено"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class ItemAdapter : BaseAdapter() {
        private var data: List<Item> = emptyList()

        fun refresh() {
            data = Store.snapshot()
            notifyDataSetChanged()
        }

        override fun getCount() = data.size
        override fun getItem(position: Int): Item = data[position]
        override fun getItemId(position: Int): Long = data[position].id.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val ctx = this@MainActivity
            val item = data[position]
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(10), 0, dp(10))
            }
            box.addView(TextView(ctx).apply {
                text = item.name
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
            })
            if (item.status == Status.DOWNLOADING || item.status == Status.QUEUED) {
                box.addView(
                    ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
                        max = 100
                        progress = item.progress
                    },
                    LinearLayout.LayoutParams(MATCH, WRAP)
                )
            }
            box.addView(TextView(ctx).apply {
                text = statusText(item)
                textSize = 13f
            })
            return box
        }
    }
}
