package com.m3u8loader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.util.concurrent.Executors

class DownloadService : Service() {

    companion object {
        const val CH = "downloads"
        const val FG_ID = 1
    }

    private val lock = Any()
    private var running = false
    private var lastStartId = 0
    private val executor = Executors.newSingleThreadExecutor()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel()
        val n = progressNotification("Подготовка…", 0)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(FG_ID, n)
        }
        synchronized(lock) {
            lastStartId = startId
            if (!running) {
                running = true
                executor.execute { loop() }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    private fun loop() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "m3u8loader:dl")
        wl.acquire(6 * 60 * 60 * 1000L)
        var sid = 0
        try {
            while (true) {
                val item = synchronized(lock) {
                    val next = Store.nextQueued()
                    if (next == null) {
                        running = false
                        sid = lastStartId
                    }
                    next
                } ?: break
                update(item, 0)
                Downloader.run(this, item) { update(item, item.progress) }
                finishNotification(item)
            }
        } catch (t: Throwable) {
            synchronized(lock) {
                running = false
                sid = lastStartId
            }
        } finally {
            if (wl.isHeld) wl.release()
        }
        stopSelf(sid)
    }

    private fun update(item: Item, pct: Int) {
        val left = Store.queuedCount()
        val text = if (left > 0) "${item.name} · в очереди: $left" else item.name
        nm().notify(FG_ID, progressNotification(text, pct))
    }

    private fun finishNotification(item: Item) {
        val (title, icon) = when (item.status) {
            Status.DONE -> "Готово" to android.R.drawable.stat_sys_download_done
            Status.ERROR -> "Ошибка загрузки" to android.R.drawable.stat_notify_error
            else -> return
        }
        val n = builder()
            .setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText(item.name)
            .setAutoCancel(true)
            .setContentIntent(openIntent())
            .build()
        nm().notify(100 + item.id, n)
    }

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm().createNotificationChannel(
                NotificationChannel(CH, "Загрузки", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun builder(): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)

    private fun openIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun progressNotification(text: String, pct: Int): Notification =
        builder()
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("M3U8 Loader")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, false)
            .setContentIntent(openIntent())
            .build()
}
