package com.m3u8loader

import android.os.Handler
import android.os.Looper

enum class Status { QUEUED, DOWNLOADING, DONE, ERROR, CANCELLED }

class Item(val id: Int, val url: String, val name: String) {
    @Volatile var status = Status.QUEUED
    @Volatile var progress = 0
    @Volatile var message = ""
    @Volatile var cancelled = false
}

object Store {
    private val items = ArrayList<Item>()
    private var nextId = 1
    private val main = Handler(Looper.getMainLooper())
    @Volatile var listener: (() -> Unit)? = null

    @Synchronized fun add(url: String, name: String): Item {
        val item = Item(nextId++, url, name)
        items.add(item)
        return item
    }

    @Synchronized fun nextQueued(): Item? = items.firstOrNull { it.status == Status.QUEUED }

    @Synchronized fun queuedCount(): Int = items.count { it.status == Status.QUEUED }

    @Synchronized fun remove(item: Item) { items.remove(item) }

    @Synchronized fun cancel(item: Item) {
        item.cancelled = true
        if (item.status == Status.QUEUED) item.status = Status.CANCELLED
    }

    @Synchronized fun snapshot(): List<Item> = ArrayList(items)

    fun changed() {
        main.post { listener?.invoke() }
    }
}
