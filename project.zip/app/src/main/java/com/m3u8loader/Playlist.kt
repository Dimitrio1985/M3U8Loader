package com.m3u8loader

import java.net.HttpURLConnection
import java.net.URL

class Variant(val url: String, val bandwidth: Long, val height: Int) {
    fun label(): String {
        val q = if (height > 0) "${height}p" else "Авто"
        return "$q • ${bandwidth / 1000} кбит/с"
    }
    fun suffix(): String = if (height > 0) "_${height}p" else ""
}

class Segment(val url: String, val keyUrl: String?, val iv: ByteArray?, val seq: Long)

class Media(val segments: List<Segment>, val mapUrl: String?)

object Playlist {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private val ATTR = Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)")

    fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", UA)
        return c
    }

    fun fetchText(url: String): String {
        val c = open(url)
        try {
            val t = c.inputStream.bufferedReader().use { it.readText() }
            if (!t.removePrefix("\uFEFF").trimStart().startsWith("#EXTM3U")) {
                throw IllegalStateException("это не m3u8-плейлист")
            }
            return t
        } finally {
            c.disconnect()
        }
    }

    fun isMaster(text: String) = text.contains("#EXT-X-STREAM-INF")

    fun baseName(url: String): String {
        val last = try { URL(url).path.substringAfterLast('/') } catch (e: Exception) { "" }
        val n = last.substringBeforeLast('.').replace(Regex("[^\\p{L}\\p{N}_-]"), "_").take(50)
        return if (n.isBlank()) "video" else n
    }

    fun parseMaster(text: String, base: String): List<Variant> {
        val out = ArrayList<Variant>()
        val lines = text.lines().map { it.trim() }
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("#EXT-X-STREAM-INF:")) {
                val a = attrs(l.substringAfter(':'))
                var j = i + 1
                while (j < lines.size && (lines[j].isEmpty() || lines[j].startsWith("#"))) j++
                if (j < lines.size) {
                    val bw = a["BANDWIDTH"]?.toLongOrNull() ?: 0L
                    val h = a["RESOLUTION"]?.substringAfter('x', "")?.toIntOrNull() ?: 0
                    out.add(Variant(resolve(base, lines[j]), bw, h))
                }
                i = j
            }
            i++
        }
        if (out.isEmpty()) throw IllegalStateException("в мастер-плейлисте нет потоков")
        return out
    }

    fun parseMedia(text: String, base: String): Media {
        val segs = ArrayList<Segment>()
        var seq = 0L
        var keyUrl: String? = null
        var iv: ByteArray? = null
        var mapUrl: String? = null
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#")) {
                if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                    seq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                } else if (l.startsWith("#EXT-X-KEY:")) {
                    val a = attrs(l.substringAfter(':'))
                    val method = a["METHOD"]
                    if (method == "NONE") {
                        keyUrl = null
                        iv = null
                    } else if (method == "AES-128") {
                        keyUrl = a["URI"]?.let { resolve(base, it) }
                        iv = a["IV"]?.let { parseIv(it) }
                    } else {
                        throw IllegalStateException("шифрование $method не поддерживается")
                    }
                } else if (l.startsWith("#EXT-X-MAP:")) {
                    mapUrl = attrs(l.substringAfter(':'))["URI"]?.let { resolve(base, it) }
                }
            } else {
                segs.add(Segment(resolve(base, l), keyUrl, iv, seq))
                seq++
            }
        }
        if (segs.isEmpty()) throw IllegalStateException("в плейлисте нет сегментов")
        return Media(segs, mapUrl)
    }

    private fun attrs(s: String): Map<String, String> =
        ATTR.findAll(s).associate { it.groupValues[1] to it.groupValues[2].trim('"') }

    private fun parseIv(s: String): ByteArray {
        val hex = s.removePrefix("0x").removePrefix("0X").padStart(32, '0')
        return ByteArray(16) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    private fun resolve(base: String, ref: String): String = URL(URL(base), ref).toString()
}
